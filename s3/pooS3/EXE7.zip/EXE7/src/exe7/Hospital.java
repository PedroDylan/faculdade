package exe7;

public class Hospital {
	private String nome;
	private String endereco;
	
}
