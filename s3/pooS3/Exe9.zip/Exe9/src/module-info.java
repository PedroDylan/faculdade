/**
 * 
 */
/**
 * 
 */
module Exe9 {
	requires java.desktop;
}